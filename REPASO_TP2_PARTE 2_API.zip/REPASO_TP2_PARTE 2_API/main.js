const generar_provincia = async () => {
    const provincias = await fetch("https://apis.datos.gob.ar/georef/api/provincias")

    const provin_final = await provincias.json()

    let filas = []
    provin_final.forEach(element => {

        let fila=
        `
        <tr>
            <td>${element.id}</td>
            <td>${element.nombre}</td>
        </tr>
        `

        filas.push(fila)
    });

    document.getElementById("tbl_body").innerHTML = filas.join('')
}

generar_provincia()

